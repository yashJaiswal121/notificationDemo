import React, { Component } from 'react';
import openSocket from 'socket.io-client';

export class Admin extends Component {

    socket=null;
     constructor(props)
     {
       super(props);
       this.state={}
      this.socket = openSocket('http://localhost:8000'); //server ip and listening port
    
     this.checkNotifications=this.checkNotifications.bind(this);
     
     }
     checkNotifications(){
         this.socket.on('notifications', obj => {
            console.log(obj)   //  callback 
            }
             );
         this.socket.emit('subscribeToNotify', 'admin','NotificationReciever');

     }
     
     render(){
        
        setInterval(()=>{
            this.checkNotifications()
          },2000);
        return(<div>
            In Admin
        </div>);

     }

     
    }   
   